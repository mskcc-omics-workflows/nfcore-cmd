from pathlib import Path 
import pytest
import sys


test_path = Path("aha") / "bcl" / "test.yml"
module_name = "bcl"
command_args = ["test_run.py", "--yml", test_path, "--module", module_name, "--symlink", "--keep-workflow-wd", "--git-aware"]
sys.exit(pytest.main(command_args))
